PS5DreamcastX - licences, notices and sources
=========================================

Release: development build

PIRACY IS NOT CONDONED. This title contains no games, no BIOS files, no
console firmware and no decryption keys, and none will ever be provided or
linked to. Use only games you own, as backups you made yourself from your own
discs, and BIOS files dumped from hardware you own. Downloading or sharing
games, BIOS files, firmware or keys you do not own is piracy: do not do it,
and do not ask for help with it.

Licences: PS5DreamcastX as a whole is distributed under the GNU General Public
License, version 3, WITHOUT ANY WARRANTY. Every part of it, its licence and
its source are listed in licenses/README.txt; the licence texts are in
licenses/.

PS5DreamcastX is an unofficial port of Flycast. It is not affiliated with or
endorsed by Sony Interactive Entertainment, Sega or the Flycast project.
"PlayStation" and "PS5" are trademarks of Sony Interactive Entertainment;
"Dreamcast" is a trademark of Sega. Vulkan is a registered trademark of the
Khronos Group, and the RADV port in this title is not a conformant product.

This folder lists every part of this title, the licence each is under, the
licence texts those licences require to travel with it, and the source
revision each part was built from. components.json holds the same, with the
sha256 of every executable file.

Corresponding source: the release page this title was downloaded from carries
the complete source of everything in it, one archive per part, with
SOURCES.txt saying what each is (made by shell/ps5/release/source-bundle.py).
Flycast and the libraries it carries are in PS5DreamcastX's own source archive.

Not included: no games, BIOS files, console firmware or decryption keys.

Parts
-----

PS5DreamcastX (this port: the PS5 platform code, the interface, the build and release scripts)
  kind:      code
  licence:   GPL-3.0 as a whole (the combined title); its own files are GPL-2.0-or-later, and GPL-3.0-or-later where they come from the PS5 title pipeline
  copyright: Copyright 2026 the PSFlyCast contributors
  copyright: Copyright (C) 2026 BlackBearReloaded and Mihawk (the title's start-up and link layout, shell/ps5/runtime)
  texts:     psflycast/GPL-3.0.txt
  source:    the repository this release is published from, at the release's tag; and the archive PS5DreamcastX-<tag>-source.tar.xz attached to the release
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   This is the port itself: shell/ps5/ and the changes to Flycast listed under Flycast.
  files:     BUILD.txt, LEGAL.txt, MANUAL.md, README.md, eboot.bin, sce_sys/param.json

Flycast, the Dreamcast, NAOMI and Atomiswave emulator
  kind:      code
  licence:   GPL-2.0-or-later
  copyright: Copyright the Flycast contributors (flyinghead and others), and the authors of reicast and nullDC before them (per-file notices in the source)
  texts:     flycast/GPL-2.0.txt
  source:    https://github.com/flyinghead/flycast
  source:    merged into this title's repository; the archive PS5DreamcastX-<tag>-source.tar.xz holds it with the submodules the build uses
  revision:  4dca1988dab56f603c2309e8882e264252fa7c8f
  changes:   Changed for the console, behind __PROSPERO__, FLYCAST_PS5 or USE_PS5, or with a fix from one of Flycast's open pull requests (#2213, #2384, #2414, #2415, #2416, #2513, #2519, #2520, #2521, #2528, #2531; each is named where it is applied or in shell/ps5/README.md): CMakeLists.txt, core/achievements/achievements.cpp, core/archive/rzip.cpp, core/cfg/option.cpp, core/emulator.cpp, core/hw/maple/maple_cfg.cpp, core/hw/naomi/naomi_cart.cpp, core/hw/pvr/Renderer_if.cpp, core/hw/pvr/Renderer_if.h, core/hw/sh4/sh4_core_regs.cpp, core/imgread/chd.cpp, core/imgread/isofs.cpp, core/input/gamepad_device.cpp, core/input/gamepad_device.h, core/input/mouse.cpp, core/linux/common.cpp, core/linux/posix_vmem.cpp, core/linux/unwind_info.cpp, core/network/dns.cpp, core/network/ggpo.cpp, core/network/picoppp.cpp, core/nullDC.cpp, core/oslib/http_client.cpp, core/oslib/i18n.cpp, core/oslib/oslib.cpp, core/oslib/storage.cpp, core/oslib/virtmem.h, core/rend/transform_matrix.cpp, core/rend/vulkan/compiler.cpp, core/rend/vulkan/compiler.h, core/rend/vulkan/drawer.cpp, core/rend/vulkan/drawer.h, core/rend/vulkan/oit/oit_buffer.h, core/rend/vulkan/oit/oit_pipeline.cpp, core/rend/vulkan/oit/oit_pipeline.h, core/rend/vulkan/oit/oit_renderer.cpp, core/rend/vulkan/pipeline.h, core/rend/vulkan/pipeline_warm.h, core/rend/vulkan/vulkan_context.cpp, core/rend/vulkan/vulkan_renderer.cpp, core/rend/vulkan/vulkan_renderer.h, core/stdclass.cpp, core/stdclass.h, core/ui/boxart/boxart.cpp, core/ui/game_scanner.cpp, core/ui/game_scanner.h, core/ui/gui.cpp, core/ui/gui_util.h, core/ui/mainui.cpp; and added: core/rend/soft (the Software renderer setting, listed below). 389 of its source files state GPL-2.0-or-later, the others carry no notice, and its LICENSE file is the GPL-2.0 text. Flycast's own resources are in the executable as upstream ships them: default settings memory for some arcade boards, printer fonts, the HLE BIOS's font, translations.
  files:     eboot.bin

Dear ImGui 1.92.6
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2014-2026 Omar Cornut
  texts:     imgui/MIT.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   As Flycast carries it (with its CJK additions).
  files:     eboot.bin

glslang (the shader compiler)
  kind:      code
  licence:   BSD-3-Clause AND others stated in LICENSE.txt
  copyright: Copyright the Khronos Group, LunarG, Google, NVIDIA, 3Dlabs and others (LICENSE.txt)
  texts:     glslang/LICENSE.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Vulkan-Headers
  kind:      code
  licence:   Apache-2.0 OR MIT
  copyright: Copyright 2015-2026 The Khronos Group Inc.
  texts:     vulkan-headers/LICENSE.md, vulkan-headers/LICENSES
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Vulkan Memory Allocator
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2017-2025 Advanced Micro Devices, Inc.
  texts:     vma/LICENSE.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Asio
  kind:      code
  licence:   BSL-1.0
  copyright: Copyright (c) 2003-2024 Christopher M. Kohlhoff
  texts:     asio/LICENSE_1_0.txt, asio/COPYING
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

FreeType
  kind:      code
  licence:   FTL (the FreeType Project License; FreeType is offered under FTL or GPL-2.0, and is used here under FTL)
  copyright: Copyright (C) 1996-2025 David Turner, Robert Wilhelm, Werner Lemberg and the FreeType contributors
  texts:     freetype/LICENSE.TXT, freetype/FTL.TXT
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

libchdr, with zstd 1.5.6, the LZMA SDK 24.05, dr_flac and zlib 1.3.1 in it
  kind:      code
  licence:   BSD-3-Clause; zstd BSD-3-Clause; LZMA SDK public domain; dr_flac public domain or MIT-0; zlib Zlib
  copyright: Copyright Romain Tisserand (libchdr)
  copyright: Copyright (c) Meta Platforms, Inc. and affiliates (zstd)
  copyright: Igor Pavlov (LZMA SDK, public domain)
  copyright: David Reid (dr_flac)
  copyright: Copyright (C) 1995-2024 Jean-loup Gailly and Mark Adler (zlib)
  texts:     libchdr/LICENSE.txt, libchdr/zstd-LICENSE, libchdr/zlib-LICENSE, libchdr/dr_flac-licence.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

libjuice
  kind:      code
  licence:   MPL-2.0
  copyright: Copyright (c) 2020-2024 Paul-Louis Ageneau
  texts:     libjuice/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

libzip
  kind:      code
  licence:   BSD-3-Clause
  copyright: Copyright (C) 1999-2020 Dieter Baron and Thomas Klausner
  texts:     libzip/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

LZMA SDK (7-Zip's, for .7z arcade sets)
  kind:      code
  licence:   public domain
  copyright: Igor Pavlov, public domain (each file says so)
  texts:     lzma-sdk/LzmaDec.c-header.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

picoTCP
  kind:      code
  licence:   GPL-2.0-only OR GPL-3.0-only; used here under GPL-3.0
  copyright: Copyright (c) 2012-2017 Altran Intelligent Systems
  texts:     picotcp/COPYING, picotcp/LICENSE.GPLv3, picotcp/LICENSE.GPLv2
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

rcheevos
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2018 RetroAchievements.org
  texts:     rcheevos/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

tinygettext
  kind:      code
  licence:   Zlib
  copyright: Copyright (c) 2004-2016 Ingo Ruhnke and the tinygettext contributors
  texts:     tinygettext/LICENSE.md
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

WebSocket++
  kind:      code
  licence:   BSD-3-Clause, with parts under other permissive licences (COPYING)
  copyright: Copyright (c) 2014, Peter Thorson
  texts:     websocketpp/COPYING
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

xBRZ
  kind:      code
  licence:   GPL-3.0
  copyright: Copyright (c) Zenju (zenju AT gmx DOT de)
  texts:     xbrz/License.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Xbyak (the dynarec's assembler)
  kind:      code
  licence:   BSD-3-Clause
  copyright: Copyright (c) 2007 MITSUNARI Shigeo
  texts:     xbyak/COPYRIGHT
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

xxHash
  kind:      code
  licence:   BSD-2-Clause
  copyright: Copyright (c) 2012-2021 Yann Collet
  texts:     xxhash/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Basis Universal transcoder
  kind:      code
  licence:   Apache-2.0
  copyright: Copyright (c) 2016-2026 Binomial LLC. "Basis Universal" is a trademark of Binomial LLC.
  texts:     basis-universal/LICENSE, basis-universal/NOTICE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it: the transcoder only (transcoder/basisu_transcoder.cpp), for compressed custom textures.
  files:     eboot.bin

Zstandard decompressor (single file, in Basis Universal)
  kind:      code
  licence:   BSD-3-Clause
  copyright: Copyright (c) Meta Platforms, Inc. and affiliates.
  texts:     zstd-decoder/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Basis Universal carries it (zstd/zstddeclib.c).
  files:     eboot.bin

FidelityFX Super Resolution 1.0 (the Upscaling setting)
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2021 Advanced Micro Devices, Inc. All rights reserved.
  texts:     fsr1/LICENSE.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified: ffx_a.h and ffx_fsr1.h of https://github.com/GPUOpen-Effects/FidelityFX-FSR at a21ffb8f6c13233ba336352bdff293894c706575 (v1.0.2), in shell/ps5/fsr, compiled as GLSL by shell/ps5/ps5_fsr.cpp.
  files:     eboot.bin

REFSW, the software model of the Dreamcast's graphics chip (the Software renderer setting)
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2025 emudev-org (nullDC-rust; REFSW is by Stefanos Kornilios Mitsis Poiitidis)
  texts:     refsw/LICENSE.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Derived from crates/refsw2-cpp/ffi of https://github.com/skmp/nullDC-rust at 6b76ff00ebd7bdab06ac864612839708f595c714 (refsw_tile, refsw_lists, core_structs, gentable, TexUtils; their own headers say they are part of libswirl): in core/rend/soft/refsw_*.{h,cpp}, changed to render tiles on several threads from Flycast's parsed frame and to write Flycast's frame buffer. soft_renderer.{h,cpp}, which feeds it, is this port's own (GPL-2.0-or-later).
  files:     eboot.bin

OpenGL Mathematics (GLM)
  kind:      code
  licence:   MIT OR The Happy Bunny License
  copyright: Copyright (c) 2005 - G-Truc Creation
  texts:     glm/copying.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Boost.Nowide (standalone)
  kind:      code
  licence:   BSL-1.0
  copyright: Copyright (c) 2012 Artyom Beilis and the Nowide contributors
  texts:     nowide/LICENSE
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

JSON for Modern C++ 3.10.5
  kind:      code
  licence:   MIT
  copyright: Copyright (c) 2013-2022 Niels Lohmann
  texts:     json/json.hpp-header.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

stb_image and stb_image_write
  kind:      code
  licence:   MIT OR public domain (Unlicense)
  copyright: Copyright (c) 2017 Sean Barrett
  texts:     stb/stb_image.h-licence.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

GGPO
  kind:      code
  licence:   MIT
  copyright: Copyright 2009 GroundStorm Studios, LLC.
  texts:     ggpo/MIT.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   As Flycast carries it, with one change: network/udp_proto.cpp checks an input packet before decoding it (flyinghead/flycast#2519).
  files:     eboot.bin

libelf (University of New South Wales)
  kind:      code
  licence:   BSD-2-Clause
  copyright: Copyright (c) 1999-2004 University of New South Wales
  texts:     libelf/BSD-2-Clause.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

MiniUPnPc
  kind:      code
  licence:   BSD-3-Clause
  copyright: Copyright (c) 2005-2025, Thomas BERNARD
  texts:     miniupnpc/BSD-3-Clause.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Small parts Flycast carries without a licence file of their own: the MD5 code (core/deps/md5, from github.com/ulwanski/md5) and the CDI image reader (core/deps/chdpsr)
  kind:      code
  licence:   as Flycast distributes them, under its GPL-2.0-or-later
  copyright: Their authors, as named in Flycast's source
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified, as Flycast carries it.
  files:     eboot.bin

Fonts in the executable: Roboto Medium and Bold, Font Awesome Free 6 Solid
  kind:      asset
  licence:   Roboto: Apache-2.0; Font Awesome Free's fonts: SIL OFL 1.1
  copyright: Roboto: Copyright 2011 Google Inc.
  copyright: Font Awesome Free: Copyright (c) Fonticons, Inc. (https://fontawesome.com)
  texts:     fonts/Apache-2.0.txt, fonts/OFL-1.1.txt
  source:    in this title's repository (Flycast's core/deps, its submodules and fonts/), at this revision
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Unmodified; fonts/ in Flycast's source.
  files:     eboot.bin

RADV, Mesa's Vulkan driver, and the parts of Mesa it links, zlib 1.3.1 among them (PS5_Mesa fork with the PS5 winsys)
  kind:      code
  licence:   MIT AND others stated per file (see Mesa-license.rst); zlib: Zlib
  copyright: Copyright the Mesa contributors (per-file notices in the source)
  copyright: Copyright (C) 1995-2024 Jean-loup Gailly and Mark Adler (zlib)
  texts:     radv/Mesa-license.rst, radv/licenses, radv/zlib-LICENSE.txt
  source:    https://github.com/mihawk-99/PS5_Mesa
  source:    PS5_Mesa at the base revision, plus this repository's shell/ps5/mesa/*.patch; the whole tree as built is the archive PS5_Mesa-<revision>.tar.xz attached to the release
  revision:  86da95cdab4add7cfe7aef7b7dd3349973a8413c
  base:      7b59ef27c1b09b9671bc4153c41940c3155c3af2
  changes:   The fork's commits over Mesa (the PS5 winsys and VideoOut WSI), and two more for this title: 119.88 Hz on a VRR display, where a title may ask for 59.94 Hz; and a title may ask the output to leave its fixed rate, for variable refresh (shell/ps5/mesa/).
  files:     eboot.bin

PS5_Vulkan: the RADV link recipe, the linker script and the tool that makes eboot.bin
  kind:      code
  licence:   GPL-3.0-or-later
  copyright: Copyright (C) 2026 Mihawk
  copyright: Copyright (C) 2026 BlackBearReloaded
  texts:     ps5-vulkan/GPL-3.0.txt, ps5-vulkan/NOTICE.md
  source:    https://github.com/mihawk-99/PS5_Vulkan
  source:    PS5_Vulkan at the base revision with one line changed; the tree as built is the archive PS5_Vulkan-<revision>.tar.xz attached to the release
  revision:  5b5e4fc2d80fdb67a4f61ba9e6a8a424026bb8a5 (with uncommitted changes)
  base:      5b5e4fc2d80fdb67a4f61ba9e6a8a424026bb8a5
  note:      with tools/build-radv.sh's mesa_revision set to the RADV revision above
  changes:   Unmodified but for the Mesa revision its build-radv.sh names.
  files:     eboot.bin

sce_module/libc.prx, the generated loader companion (ps5-native-app-boilerplate)
  kind:      code
  licence:   GPL-3.0-or-later
  copyright: Copyright (C) 2026 BlackBearReloaded
  texts:     libc-prx-shim/GPL-3.0.txt
  source:    https://github.com/mihawk-99/PS5_Vulkan
  revision:  5b5e4fc2d80fdb67a4f61ba9e6a8a424026bb8a5 (with uncommitted changes)
  changes:   Generated by PS5_Vulkan's tools/rebuild-libc.sh; runtime/libc.prx.sha256 there is its expected digest. It holds generated stubs and loader metadata (exported symbol names and sizes), no code taken from a console.
  files:     sce_module/libc.prx

PS5 payload SDK fork and its platform layer (libps5platform.a, headers, import stubs)
  kind:      code
  licence:   GPL-3.0-or-later
  copyright: Copyright (C) 2022-2026 John Törnblom and ps5-payload-dev contributors
  copyright: Copyright (C) 2026 Mihawk (the platform layer)
  texts:     payload-sdk/GPL-3.0.txt, payload-sdk/musl-regex-COPYRIGHT.txt, payload-sdk/dlmalloc-SOURCE.txt
  source:    https://github.com/mihawk-99/PS5_PayloadSDK
  revision:  611893fc25ef3e138f5bc2c90d829d8b58174cd2
  also:      b83202be73e930050e00de0f1b4d9ec46c0391bf (the revision RADV's archive was compiled with)
  changes:   The fork installs over the ps5-payload-dev SDK v0.42 release. The platform layer's regex is musl's (MIT, with TRE's BSD-2-Clause notice) and its heap is dlmalloc 2.8.6 (MIT). The title is compiled with the fork at the revision given; RADV's archive was compiled with the one PROVENANCE.txt names.
  files:     eboot.bin, sandbox-elevator.elf

LLVM libc++, libc++abi, libunwind and compiler-rt builtins (statically linked)
  kind:      code
  licence:   Apache-2.0 WITH LLVM-exception
  copyright: Copyright (c) 2003-2026 University of Illinois at Urbana-Champaign and the LLVM project contributors
  texts:     llvm-runtime/LICENSE.TXT
  source:    https://github.com/ps5-payload-dev/sdk/releases/tag/v0.42
  revision:  ps5-payload-dev SDK v0.42 release archives
  changes:   Unmodified release archives of the SDK.
  files:     eboot.bin

sandbox-elevator.elf and its client: USB drive access (the sandbox-elevation example of ps5-native-app-boilerplate)
  kind:      code
  licence:   GPL-3.0
  copyright: Copyright (C) 2026 BlackBearReloaded
  copyright: Copyright 2026 the PSFlyCast contributors (its use in this title)
  texts:     sandbox-elevator/GPL-3.0.txt
  source:    shell/ps5/elevation/ in this title's repository; upstream: https://github.com/BlackBearReloaded/ps5-native-app-boilerplate
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   The example's helper and protocol, adapted to this title (shell/ps5/elevation/).
  files:     eboot.bin, sandbox-elevator.elf

libsmb2 (games on network shares)
  kind:      code
  licence:   LGPL-2.1-or-later
  copyright: Copyright (C) Ronnie Sahlberg and the libsmb2 contributors
  texts:     libsmb2/LICENCE-LGPL-2.1.txt, libsmb2/COPYING
  source:    https://github.com/sahlberg/libsmb2
  revision:  7e4ff97cf00edb288b6b763888e4326842afdc76
  changes:   Unmodified; compiled with this title's shell/ps5/smb/config.h and ps5_smb_compat.c. It is linked statically: the source archives attached to the release are what relinking it needs.
  files:     eboot.bin

The title's icon, the pictures and the sound the console shows and plays for it (sce_sys), and the start-up sound
  kind:      asset
  licence:   GPL-3.0-or-later
  copyright: Copyright 2026 the PSFlyCast contributors
  source:    shell/ps5/sce_sys/ and shell/ps5/sounds/ in this title's repository
  revision:  1cc6b2978d891f93cd2e36123ba4fd14118bd444 (with uncommitted changes)
  changes:   Made for this project. icon0.png is the app's mark and name, drawn by shell/ps5/sce_sys/make-icon.py. pic0.dds (the home screen) is the mark and the name as the start-up animation has them, and pic1.dds (while the title loads) the animation's first frame; both are rendered from the interface's own code (shell/ps5/bigpicture.cpp) and encoded with PS5_Vulkan's tools/prepare-assets.sh. sounds/startup.wav is the start-up sound, by Press5elect, the project's author, for this project. sce_sys/snd0.at9 (the home screen's sound) is the output of shell/ps5/sounds/make-home-sound.py, which makes a loop from sine waves, encoded to ATRAC9 with ps5-at9-converter (BlackBearReloaded, GPL-3.0-or-later; a tool, none of it is in the file).
  files:     sce_sys/icon0.png, sounds/startup.wav
